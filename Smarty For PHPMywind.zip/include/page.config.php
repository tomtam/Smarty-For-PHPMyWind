<?php
return array (
  //首页
  "index" => array(
  	"tpl" => "index.htm"
  ),
  //单页
  "about" => array(
  	"tpl" => "about.htm"
  ),
  //文章列表
  "news_list" => array(
  	"tpl" => "news_list.htm"
  ),
  //文章详情
  "news_show" => array(
  	"tpl" => "news_show.htm"
  ),
  //图文列表
  "products_list" => array(
  	"tpl" => "products_list.htm"
  ),
  //图文详情
  "products_show" => array(
  	"tpl" => "products_show.htm"
  )
)
?>